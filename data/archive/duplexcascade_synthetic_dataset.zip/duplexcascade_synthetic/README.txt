DuplexCascade-style synthetic micro-turn dataset

Files: micro_turns_train.jsonl, micro_turns_val.jsonl, micro_turns_test.jsonl
Schema matches the starter JSONL: id, scenario, topic, micro_turns[{user,assistant}], messages.
Splits are conversation-disjoint by record ID.

IMPORTANT LIMITATIONS
This is a synthetic starter dataset generated from reusable scenario templates, not a gold-standard or production-ready dataset. Variants are mostly structural/lexical and are not independent human conversations. Do not interpret its metrics as evidence of real-world duplex performance. Audit labels, expand with human-reviewed examples, and test with real ASR traces before deployment.

Action semantics: assistant="listen" means emit no speech this micro-turn; any other assistant string is a speech fragment. "no voice" is the user-side empty audio/ASR result.

Suggested evaluation: listen/speak macro-F1; premature interruption rate; missed interruption rate; repeated-fragment rate; completion rate; safety-interruption recall; latency budget compliance; and human ratings of naturalness. Report per-scenario results, not only aggregate accuracy.

Audit summary
train: 480 conversations, 4372 micro-turns, listen=2343, speak=2029, scenarios=21
val: 60 conversations, 550 micro-turns, listen=296, speak=254, scenarios=20
test: 60 conversations, 562 micro-turns, listen=304, speak=258, scenarios=20
